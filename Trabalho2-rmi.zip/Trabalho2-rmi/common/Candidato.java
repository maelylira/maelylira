package common;
import java.io.Serializable;

public class Candidato implements Serializable {
    private String id;
    private String nome;
    private int votos;

    public Candidato(String id, String nome) {
        this.id = id;
        this.nome = nome;
        this.votos = 0;
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
    public int getVotos() { return votos; }
    public void adicionarVoto() { votos++; }
}