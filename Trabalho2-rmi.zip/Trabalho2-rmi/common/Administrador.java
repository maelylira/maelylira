package common;

public class Administrador extends Pessoa {
    public Administrador(String id, String nome) {
        super(id, nome);
    }
}
