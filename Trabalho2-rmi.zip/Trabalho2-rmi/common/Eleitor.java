package common;

public class Eleitor extends Pessoa {
    public Eleitor(String id, String nome) {
        super(id, nome);
    }
}