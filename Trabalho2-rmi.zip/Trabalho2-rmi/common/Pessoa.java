package common;


import java.io.Serializable;

public abstract class Pessoa implements Serializable {
    protected String id;
    protected String nome;

    public Pessoa(String id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public String getId() { return id; }
    public String getNome() { return nome; }
}
