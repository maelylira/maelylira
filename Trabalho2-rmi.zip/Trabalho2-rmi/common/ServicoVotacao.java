package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ServicoVotacao extends Remote {
    String login(String idEleitor) throws RemoteException;
    List<Candidato> listarCandidatos() throws RemoteException;
    String votar(String idEleitor, String idCandidato) throws RemoteException;
    String cadastrarCandidato(Candidato candidato) throws RemoteException;
}