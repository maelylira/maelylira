package server;

import common.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.*;

public class ServicoVotacaoImpl extends UnicastRemoteObject implements ServicoVotacao {
    private Map<String, Eleitor> eleitores;
    private Map<String, Candidato> candidatos;

    public ServicoVotacaoImpl() throws RemoteException {
        eleitores = new HashMap<>();
        candidatos = new HashMap<>();
        // Candidatos iniciais
        candidatos.put("c1", new Candidato("c1", "João"));
        candidatos.put("c2", new Candidato("c2", "Maria"));
    }

    @Override
    public String login(String idEleitor) {
        if (!eleitores.containsKey(idEleitor)) {
            eleitores.put(idEleitor, new Eleitor(idEleitor, "Eleitor " + idEleitor));
            return "Login realizado com sucesso.";
        }
        return "Eleitor já logado.";
    }

    @Override
    public List<Candidato> listarCandidatos() {
        return new ArrayList<>(candidatos.values());
    }

    @Override
    public String votar(String idEleitor, String idCandidato) {
        if (!eleitores.containsKey(idEleitor)) return "Eleitor não encontrado.";
        Candidato candidato = candidatos.get(idCandidato);
        if (candidato == null) return "Candidato não encontrado.";
        candidato.adicionarVoto();
        return "Voto registrado com sucesso.";
    }

    @Override
    public String cadastrarCandidato(Candidato candidato) {
        if (candidatos.containsKey(candidato.getId())) return "Candidato já existe.";
        candidatos.put(candidato.getId(), candidato);
        return "Candidato cadastrado.";
    }
}
