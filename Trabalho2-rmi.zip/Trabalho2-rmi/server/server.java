package server;

import common.ServicoVotacao;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class server {
    public static void main(String[] args) {
        try {
            ServicoVotacao servico = new ServicoVotacaoImpl();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("Votacao", servico);
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
