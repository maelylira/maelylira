package client;

import common.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

public class cliente {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost");
            ServicoVotacao stub = (ServicoVotacao) registry.lookup("Votacao");

            System.out.println(stub.login("e1"));
            List<Candidato> lista = stub.listarCandidatos();
            for (Candidato c : lista) {
                System.out.println(c.getId() + " - " + c.getNome() + " (" + c.getVotos() + ")");
            }
            System.out.println(stub.votar("e1", "c1"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
